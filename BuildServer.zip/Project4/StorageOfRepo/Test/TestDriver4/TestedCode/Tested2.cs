﻿/////////////////////////////////////////////////////////////////////
// Tested1.cs - demonstration production code                      
// Author: Beier Chen                                                                
// Source: Jim Fawcett
// Application: CSE681 - Software Modeling and Analysis, Fall 2017 
/////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestDriver4
{
    public class Tested2
    {
        public string Say()
        {
            return "Tested2";
        }
    }
}
