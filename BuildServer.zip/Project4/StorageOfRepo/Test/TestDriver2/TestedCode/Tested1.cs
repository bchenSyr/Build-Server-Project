﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestDriver2
{
  public class Tested1
  {
    public bool Test()
    {
      Console.Write("\n  Tested1 here");
            return true;
    }
  }
}
