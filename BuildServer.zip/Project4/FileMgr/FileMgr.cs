﻿/////////////////////////////////////////////////////////////////////
// FileMgr.cs - file and directory handling 
// Author: Beier Chen, bchen22@syr.edu
// Source: Jim Fawcett
// Application: Project #4, CSE 681 Fall2017                                  
// Environment: Windows 10 Education, MacBook               
/////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * ===================
 * provides file and directory handling for other components
 * 
 * Public Interface:
 * ===================
 * FileMgrFactory class:
 * create() - select FileMgr type
 * 
 * LocalFileMgr class:
 * getFiles() - get names of all files in current directory
 * getDirs() - get names of all subdirectories in current directory
 * 
 * Required Files
 * --------------------
 * FileMgr.cs
 * 
 * Maintenance History:
 * --------------------
 * ver 1.0 : Dec 8 2017
 * - first release
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Federation
{
    public enum FileMgrType { Local, Remote }

    public interface IFileMgr
    {
        IEnumerable<string> getFiles(string dir);
        IEnumerable<string> getDirs(string dir);
        Stack<string> pathStack { get; set; }
        string currentPath { get; set; }
    }

    ///////////////////////////////////////////////////////////////////
    // FileMgrFactory class
    public class FileMgrFactory
    {
        static public IFileMgr create(FileMgrType type)
        {
            if (type == FileMgrType.Local)
                return new LocalFileMgr();
            else
                return null;  // eventually will have remote file Mgr
        }
    }

    ///////////////////////////////////////////////////////////////////
    // LocalFileMgr class
    public class LocalFileMgr : IFileMgr
    {
        public string currentPath { get; set; } = "";
        public Stack<string> pathStack { get; set; } = new Stack<string>();

        public LocalFileMgr()
        {
            pathStack.Push(currentPath);  // stack is used to move to parent directory
        }

        //----< get names of all files in current directory >------------
        public IEnumerable<string> getFiles(string Dir)
        {
            List<string> files = new List<string>();
            string path = Path.Combine(Dir, currentPath);
            string absPath = Path.GetFullPath(path);
            files = Directory.GetFiles(path).ToList<string>();
            for (int i = 0; i < files.Count(); ++i)
            {
                files[i] = Path.Combine(currentPath, Path.GetFileName(files[i]));
            }
            return files;
        }

        //----< get names of all subdirectories in current directory >---
        public IEnumerable<string> getDirs(string dir)
        {
            List<string> dirs = new List<string>();
            string path = Path.Combine(dir, currentPath);
            dirs = Directory.GetDirectories(path).ToList<string>();
            for (int i = 0; i < dirs.Count(); ++i)
            {
                string dirName = new DirectoryInfo(dirs[i]).Name;
                dirs[i] = Path.Combine(currentPath, dirName);
            }
            return dirs;
        }
    }

    ///////////////////////////////////////////////////////////////////
    // TestFileMgr class
    class TestFileMgr
    {
#if (TEST_FILEMGR)
        static void Main(string[] args)
        {
            IFileMgr fileMgr = FileMgrFactory.create(FileMgrType.Local);

            PrintTool.Line("Testing Function: getFiles()");

            string BldReqDir = "../../../StorageOfClient/BuildRequest";
            List<string> BldReqName = fileMgr.getFiles(BldReqDir).ToList<string>();

            foreach (string name in BldReqName)
            {
                Console.WriteLine("\n Build Request name is {0}", name);
            }

            PrintTool.Line("Testing Function: getDirs(");

            string TestListDir = "../../../StorageOfRepo/Test";
            List<string> dirs = fileMgr.getDirs(TestListDir).ToList<string>();
            foreach (string dir in dirs)
            {
                Console.WriteLine("\n Test dir is {0}", dir);
            }
            PrintTool.Line("End of the demonstration");
        }
#endif
    }

}
